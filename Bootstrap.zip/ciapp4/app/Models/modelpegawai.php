<?php

namespace App\Models;

use CodeIgniter\Model;

class modelpegawai extends Model
{
    protected $tabel = "pegawai";
    protected $primarykey = "id";
    protected $allowedFields = ['nama', 'email', 'bidang', 'alamat'];

    function cari($katakunci)
    {
        $builder = $this->table("pegawai");
        $arr_katakunci = explode(" ",  $katakunci);
        for ($x = 0; $x < count($arr_katakunci); $x++) {
            $builder->orlike('nama', $arr_katakunci[$x]);
            $builder->orlike('email', $arr_katakunci[$x]);
            $builder->orlike('alamat', $arr_katakunci[$x]);
        }
        return $builder;
    }
}
