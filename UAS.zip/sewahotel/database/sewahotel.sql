/*
 Navicat Premium Data Transfer

 Source Server         : BasisData
 Source Server Type    : MySQL
 Source Server Version : 100421
 Source Host           : localhost:3306
 Source Schema         : sewahotel

 Target Server Type    : MySQL
 Target Server Version : 100421
 File Encoding         : 65001

 Date: 16/04/2022 12:55:57
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `username` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_admin`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'Hotel Hebat', 'hotelhebat', 'e00cf25ad42683b3df678c61f42c6bda');
INSERT INTO `admin` VALUES (2, 'Shakira Azzahra', 'shakira', 'b2e54810f712fdc1f19613d7893f1035');
INSERT INTO `admin` VALUES (3, 'Dimas Agung', 'dimasagung', '32cacb2f994f6b42183a1300d9a3e8d6');
INSERT INTO `admin` VALUES (4, 'Harmen', 'armen', 'fc1ebc848e31e0a68e868432225e3c82');
INSERT INTO `admin` VALUES (6, 'Ariyo Banjardana', 'AriyoBanjardana', '2e6c3a2f7b6c7f9ab4fdd000c778d572');

-- ----------------------------
-- Table structure for kamar
-- ----------------------------
DROP TABLE IF EXISTS `kamar`;
CREATE TABLE `kamar`  (
  `id_kamar` int NOT NULL AUTO_INCREMENT,
  `id_tipe` int NOT NULL,
  `nama_kamar` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `no_kamar` int NOT NULL,
  `tipe_kasur` enum('Single Bed','Twin Bed','Double Bed') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `lokasi` enum('Lantai 1','Lantai 2','Lantai 3') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gambar` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tgl_input` date NOT NULL,
  `harga_kamar` int NOT NULL,
  `status_kamar` enum('1','0') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_kamar`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 9 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kamar
-- ----------------------------
INSERT INTO `kamar` VALUES (1, 1, 'Adipati', 101, 'Single Bed', 'Lantai 1', 'gambar1544332691.jpg', '2018-12-11', 400000, '1');
INSERT INTO `kamar` VALUES (2, 3, 'Kanjeng', 301, 'Double Bed', 'Lantai 3', 'gambar1544332354.jpg', '2018-12-11', 1000000, '0');
INSERT INTO `kamar` VALUES (6, 2, 'Raden', 201, 'Twin Bed', 'Lantai 2', 'gambar1544514756.jpg', '0000-00-00', 700000, '1');
INSERT INTO `kamar` VALUES (5, 3, 'Kanjeng', 302, 'Double Bed', 'Lantai 3', 'gambar1544363768.jpg', '0000-00-00', 1000000, '1');
INSERT INTO `kamar` VALUES (7, 2, 'Patih', 303, 'Twin Bed', 'Lantai 3', 'gambar1544529342.jpg', '2022-04-16', 800000, '0');
INSERT INTO `kamar` VALUES (8, 3, 'Amazing', 310, 'Single Bed', 'Lantai 3', 'gambar1650081100.jpg', '0000-00-00', 1500000, '1');

-- ----------------------------
-- Table structure for pelanggan
-- ----------------------------
DROP TABLE IF EXISTS `pelanggan`;
CREATE TABLE `pelanggan`  (
  `id_pelanggan` int NOT NULL AUTO_INCREMENT,
  `nama_pelanggan` varchar(45) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `no_telp` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `alamat` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_pelanggan`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 14 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of pelanggan
-- ----------------------------
INSERT INTO `pelanggan` VALUES (1, 'Firman Rosadi', 'Laki-Laki', '081344556678', 'Cilincing', 'firman@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (2, 'Joko Kriswanto', 'Laki-Laki', '081233336789', 'Pasar Minggu', 'joko@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (3, 'Febby Triadi', 'Laki-Laki', '081154662344', 'Rusia', 'kangfeb@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (4, 'Zaenuddin', 'Laki-Laki', '081599870090', 'Cengkareng', 'nuding@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (5, 'Fahmi Noviano', 'Laki-Laki', '089630552211', 'Pandeglang', 'noviano@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (10, 'Dimas Agung', 'Laki-Laki', '08112226789', 'Jombang', 'dimas@gmail.com', '202cb962ac59075b964b07152d234b70');
INSERT INTO `pelanggan` VALUES (8, 'Chaerullah Fadli', 'Laki-Laki', '081122255776', 'Bekasi', 'fadli@gmail.com', '123');
INSERT INTO `pelanggan` VALUES (9, 'Ahmad Husaeni', 'Laki-Laki', '082288985643', 'Jatiwaringin', 'husein@gmail.com', '202cb962ac59075b964b07152d234b70');
INSERT INTO `pelanggan` VALUES (11, 'Ricky Adam', 'Laki-Laki', '087780099779', 'Cipinang', 'ricky@gmail.com', '202cb962ac59075b964b07152d234b70');
INSERT INTO `pelanggan` VALUES (12, 'Vany', 'Perempuan', '08098888999', 'Kramat', 'vany@gmail.com', '202cb962ac59075b964b07152d234b70');
INSERT INTO `pelanggan` VALUES (13, 'Regina Anjani', 'Perempuan', '085338769599', 'labuhan, sumbawa', 'egi2002@gmail.com', '310ff7c3d0680e60855603dce416119b');

-- ----------------------------
-- Table structure for penyewaan
-- ----------------------------
DROP TABLE IF EXISTS `penyewaan`;
CREATE TABLE `penyewaan`  (
  `id_sewa` int NOT NULL AUTO_INCREMENT,
  `tgl_sewa` datetime NOT NULL,
  `id_pelanggan` int NOT NULL,
  `tgl_cekin` date NOT NULL,
  `tgl_cekout` date NOT NULL,
  `total_extend` double NOT NULL DEFAULT 0,
  `status_bayar` enum('0','1') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0',
  PRIMARY KEY (`id_sewa`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Fixed;

-- ----------------------------
-- Records of penyewaan
-- ----------------------------
INSERT INTO `penyewaan` VALUES (1, '2018-12-05 13:00:00', 1, '2018-12-06', '2018-12-07', 0, '0');

-- ----------------------------
-- Table structure for tipekamar
-- ----------------------------
DROP TABLE IF EXISTS `tipekamar`;
CREATE TABLE `tipekamar`  (
  `id_tipe` int NOT NULL AUTO_INCREMENT,
  `tipe_kamar` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_tipe`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tipekamar
-- ----------------------------
INSERT INTO `tipekamar` VALUES (1, 'Standar');
INSERT INTO `tipekamar` VALUES (2, 'Deluxe');
INSERT INTO `tipekamar` VALUES (3, 'Premium Suite');

-- ----------------------------
-- Table structure for transaksi
-- ----------------------------
DROP TABLE IF EXISTS `transaksi`;
CREATE TABLE `transaksi`  (
  `id_sewa` int NOT NULL AUTO_INCREMENT,
  `tgl_bayar` datetime NOT NULL,
  `id_pelanggan` int NOT NULL,
  `id_kamar` int NOT NULL,
  `tgl_cekin` date NOT NULL,
  `tgl_cekout` date NOT NULL,
  `extend` double NOT NULL,
  `tgl_extend` date NOT NULL,
  `total_extend` double NOT NULL,
  `status_penyewaan` varchar(15) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status_pembayaran` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_sewa`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of transaksi
-- ----------------------------
INSERT INTO `transaksi` VALUES (1, '2018-12-10 00:00:00', 1, 3, '2018-12-08', '2018-12-09', 1000000, '2018-12-10', 3000000, '1', '1');
INSERT INTO `transaksi` VALUES (16, '2018-12-10 14:14:50', 4, 2, '2018-12-08', '2018-12-09', 1000000, '2018-12-10', 0, '1', '1');
INSERT INTO `transaksi` VALUES (17, '2018-12-10 14:32:41', 2, 1, '2018-12-07', '2018-12-09', 400000, '2018-12-10', 7149983333.3333, '1', '1');
INSERT INTO `transaksi` VALUES (18, '2018-12-11 08:17:15', 5, 1, '2018-12-09', '2018-12-10', 400000, '2018-12-11', 800000, '1', '1');
INSERT INTO `transaksi` VALUES (19, '2018-12-11 08:31:32', 10, 2, '2018-12-09', '2018-12-10', 1000000, '2018-12-11', 3000000, '1', '1');
INSERT INTO `transaksi` VALUES (20, '2018-12-11 08:33:09', 3, 2, '2018-12-06', '2018-12-10', 1000000, '0000-00-00', 0, '0', '0');
INSERT INTO `transaksi` VALUES (21, '2018-12-11 12:58:24', 12, 7, '2018-12-11', '2018-12-13', 800000, '2018-12-13', 2400000, '1', '1');
INSERT INTO `transaksi` VALUES (22, '2022-04-16 05:58:10', 13, 7, '2022-04-20', '2022-04-21', 500000, '0000-00-00', 0, '0', '0');

SET FOREIGN_KEY_CHECKS = 1;
